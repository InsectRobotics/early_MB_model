% This script extracts 50 average heights
% The final inputs are normalised between 0 and 1

load Raw_images;

% Feature combination
input_num = 50;
file_num = 81;
inputs = zeros(input_num,file_num);
edges = zeros(75,359,file_num);

for j = 1 : file_num
    j
    skyline = zeros(360,1);
    
    grayview = Raw_images(j).raw_image(:,:,2);    
    edges(:,:,j) = edge(grayview,'canny',[0,0.1]);
    edge1 = edges(75:-1:1,:,j);
    idx = find(edge1 == 1);
    [r,c,p] = ind2sub(size(edge1), idx);
    [pixel_idx, skyline_idx, ic] = unique(c);
    skyline(pixel_idx) = r(skyline_idx);
    
    % calculate average heights of visible skyline over 50 segments
    r_skyline = reshape(skyline(6:355),7,50);
    unnorm_inputs = mean(r_skyline);
    %r_skyline = reshape(skyline,1,360);
    %unnorm_inputs = mean(r_skyline,1);
    % normalise to 0-1 by dividing maximum value
    inputs(:,j) = 1-unnorm_inputs/max(unnorm_inputs);

end

save('inputs','inputs');
