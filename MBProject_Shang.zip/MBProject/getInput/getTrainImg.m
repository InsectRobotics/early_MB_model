% getTrainImg gets training images along a route
% With Mike's heading data

load AntData;
load world5000_gray;

% retrieve a route from AntData
route = Ant1.InwardRouteData.Route1.One_cm_control_points/100;
heading = Ant1.InwardRouteData.Route1.One_cm_control_points_headings;

% get an image very 10 cm
img_separation = 10; % [cm]
img_limit = floor(size(route,1)/10)*10;
% 80 image positions
img_pos = zeros(2,2);
img_pos = route(1:img_separation:img_limit,:);

% parameters for invoking getViewPan
eye_height = 0.01; % [m]
resolution = 1; % [degrees/pixel]
fov = 360; % [degrees]
heading = heading(1:img_separation:img_limit,:); % [degrees]
% save raw images in structure F
Raw_images = struct;

% get images
for i = 1:size(img_pos,1)
    Raw_images(i).raw_image = ImgGrabber(img_pos(i,1),img_pos(i,2),eye_height,heading(i),X,Y,Z,colp,fov,resolution);
end

save('img_pos','img_pos');
save('Raw_images','Raw_images');

