% This script extracts 360 heights from training images
% The final inputs are normalised between 0 and 1 and saved in inputs.mat

load Raw_images;

% Feature combination
input_num = 360;
% number of raw images got from training route
file_num = 80;
inputs = zeros(input_num,file_num);
edges = zeros(75,359,file_num);

for j = 1 : file_num
    j
    skyline = zeros(360,1);
    
    grayview = Raw_images(j).raw_image(:,:,2);    
    edges(:,:,j) = edge(grayview,'canny',[0,0.1]);
    edge1 = edges(75:-1:1,:,j);
    idx = find(edge1 == 1);
    [r,c,p] = ind2sub(size(edge1), idx);
    [pixel_idx, skyline_idx, ic] = unique(c);
    skyline(pixel_idx) = r(skyline_idx);
    
    unnorm_inputs = skyline;
    % normalise to 0-1 by dividing maximum value
    inputs(:,j) = 1-unnorm_inputs/max(unnorm_inputs);

end

save('inputs','inputs');
