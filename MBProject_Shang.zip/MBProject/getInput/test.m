%function [index,max_spikes] = test(norm_inputs,step_count,scanning,turnspd)
% Sets up a network and simulates it. 
% Only testing phase. Test images in a 180-degree view.

train_signal = 0;
set_up_network;

% Import data of training images
interval = 300; % [ms]

% Total training time
number_of_inputs = size(norm_inputs,2);
t_end = interval*(number_of_inputs); % [ms]

% Time step:
dt = 0.25; % [ms]
number_of_steps = t_end/dt;
interval_steps = interval/dt;

% Input matrix
inputs = zeros(number_of_PN,number_of_steps+1);
for i_step = 1:number_of_inputs
    inputs(:,(i_step-1)*interval_steps+1:(i_step-1/6)*interval_steps) = repmat(norm_inputs(:,i_step),[1 interval_steps*5/6]);
    inputs(:,(i_step-1/6)*interval_steps+1:i_step*interval_steps) = zeros(number_of_PN,interval_steps/6);
end

% Reward signal
BA = 0;

% Recordings:
% total input current per population at each time step
%total_current_PN = zeros(t_end/dt,1);
%total_current_KC = zeros(t_end/dt,1);
%total_current_EN = zeros(t_end/dt,1);
% spikes per population
spikes_over_time_PN = zeros(number_of_PN,1*t_end); % Estimated max spike frequency: 200 hz
spikes_over_time_KC = zeros(number_of_KC,1*t_end); % Estimated max spike frequency: 200 hz
spikes_over_time_EN = zeros(number_of_EN,1*t_end); % Estimated max spike frequency: 200 hz
spike_counter_PN = zeros(number_of_PN,1);
spike_counter_KC = zeros(number_of_KC,1);
spike_counter_EN = zeros(number_of_EN,1);
spike_each_input_EN = zeros(number_of_EN,number_of_inputs);
%spike_each_input_KC = zeros(number_of_KC,number_of_inputs);
% neurotransmitter per synapse population at each time step
total_neurotransmitter_PN_KC = zeros(t_end/dt,1);
total_neurotransmitter_KC_EN = zeros(t_end/dt,1);
% individual voltage per population at each time step
%voltage_PN = zeros(number_of_PN,t_end/dt);
%voltage_KC = zeros(number_of_KC,t_end/dt);
%voltage_EN = zeros(number_of_EN,t_end/dt);
%current_PN = zeros(number_of_PN,t_end/dt);
%current_KC = zeros(number_of_KC,t_end/dt);
%current_EN = zeros(number_of_EN,t_end/dt);


for idt = 1 : number_of_steps
    
    t = idt*dt;
    I_PN = inputs(:,idt);
    i_input = floor(t/interval);
    
    if idt-i_input*interval_steps == interval_steps - 1
        if i_input >= 1
            spike_each_input_EN(i_input+1) = spike_counter_EN(1) - sum(spike_each_input_EN(1:i_input));
            %spike_each_input_KC(:,i_input+1) = spike_counter_KC - sum(spike_each_input_KC(:,1:i_input),2);
        else
            spike_each_input_EN(i_input+1) = spike_counter_EN(1);
            %spike_each_input_KC(:,i_input+1) = spike_counter_KC;
        end
        %t      
        KC = [-85*ones(number_of_KC,1), 0*ones(number_of_KC,1)];
    end   
    
    %  2) Calculate neuro transmitter (synapses)
    % 2a) PN_KC synapses    
    A = reshape(connection_matrix_PN_KC',1,number_of_PN*number_of_KC);
    B = reshape(synapses_PN_KC',1,number_of_PN*number_of_KC);
    C = reshape(repmat(spike_PN,1,number_of_KC)',1,number_of_PN*number_of_KC);
    current_value = A.*B;
    D = synapse_PN_KC(dt,C,current_value);
    synapses_PN_KC = reshape(D,number_of_KC,number_of_PN)';
     
    %total_neurotransmitter_PN_KC(idt) = sum(sum(synapses_PN_KC)); % Record
    
    % 2b) KC_EN synapses
    r_connection_matrix_KC_EN = reshape(connection_matrix_KC_EN',1,number_of_KC*number_of_EN);
    r_synapses_KC_EN = reshape(synapses_KC_EN',1,number_of_KC*number_of_EN);
    current_value = r_connection_matrix_KC_EN .* r_synapses_KC_EN;
    g = weight_matrix_KC_EN'.* r_connection_matrix_KC_EN;
    c = synaptic_tag_KC_EN'.* r_connection_matrix_KC_EN;
    d = concentration_BA_KC_EN';
    pre_post_spike_occured = spike_KC|spike_EN;
    delta_t = (t_last_spike_KC - t_last_spike_EN) .* pre_post_spike_occured;
    [S, g, c, d] = synapse_KC_EN(dt, spike_KC', current_value, g, c, delta_t, pre_post_spike_occured, d, BA);
    synapses_KC_EN = reshape(S,number_of_EN,number_of_KC)';
    weight_matrix_KC_EN = g';
    synaptic_tag_KC_EN = c';
    concentration_BA_KC_EN = d';
    
    %total_neurotransmitter_KC_EN(idt) = sum(sum(synapses_KC_EN)); % Record
    
    %  3) Calculate input currents:
    % 3a) Get input for PN from glomeruli with normalisation
    %total_current_PN(idt) = sum(I_PN); % Record

    % 3b) Input to KC
    %     Reversal potential: 0mV for excitatory synapses, -92mV for
    %     inhibitory synapses    
    r_volt_KC = repmat((0 - KC(:,1))',number_of_PN,1);
    I_KC = sum(connection_matrix_PN_KC.* weight_matrix_PN_KC .* synapses_PN_KC .* r_volt_KC)'; 
    %total_current_KC(idt) = sum(I_KC); % Record
    
    % 3c) Input to EN
    r_volt_EN = repmat((0 - EN(:,1))',number_of_KC,1);
    I_EN = sum(connection_matrix_KC_EN.* weight_matrix_KC_EN .* synapses_KC_EN .* r_volt_EN)';
    %total_current_EN(idt) = sum(I_EN); % Record
    
    %  4) Update neurons (and record spikes)
    % 4a) PN neurons
    [PN(:,1), PN(:,2), spike_PN] = neuron_PN(dt, PN(:,1), PN(:,2), I_PN);
    spike_counter_PN = spike_counter_PN + spike_PN;
    [row_ind,cow] = find(spike_PN == 1);
    cow_ind = spike_counter_PN(spike_PN.*spike_counter_PN ~= 0);
    indices = sub2ind(size(spikes_over_time_PN),row_ind,cow_ind);
    spikes_over_time_PN(indices) = t;
    
    %voltage_PN(:,idt) = PN(:,1); % Record
    %current_PN(:,idt) = PN(:,2);
    
    % 4b) KC neurons
    [KC(:,1), KC(:,2), spike_KC] = neuron_KC(dt, KC(:,1), KC(:,2), I_KC);
    spike_counter_KC = spike_counter_KC + spike_KC;
    [row_ind,cow] = find(spike_KC == 1);
    cow_ind = spike_counter_KC(spike_KC.*spike_counter_KC ~= 0);
    indices = sub2ind(size(spikes_over_time_KC),row_ind,cow_ind);
    spikes_over_time_KC(indices) = t;
    t_last_spike_KC = t * spike_KC + t_last_spike_KC .* (~spike_KC);
     
    %voltage_KC(:,idt) = KC(:,1); % Record
    %current_KC(:,idt) = KC(:,2);
    
    % 4c) EN neurons
    [EN(:,1), EN(:,2), spike_EN] = neuron_EN(dt, EN(:,1), EN(:,2), I_EN);
    for i_EN = 1 : number_of_EN        
        if spike_EN(i_EN) == 1
            spike_counter_EN(i_EN) = spike_counter_EN(i_EN) + 1; % Advance spike counter
            spikes_over_time_EN(i_EN,spike_counter_EN(i_EN)) = t;
            t_last_spike_EN(i_EN) = t;
        end
    end    
    %voltage_EN(:,idt) = EN(:,1); % Record
    %current_EN(:,idt) = EN(:,2);
end

[step_record(2,step_count), index] = min(spike_each_input_EN);
step_record(1,step_count) = index - 1;
if scanning == 1
    most_familiar_index = index - scan_range/scan_spd - 1;
    step_record(1,step_count) = scan_spd*most_familiar_index;
end

save(sprintf('./results1/spike_each_input_EN%03d',step_count),'spike_each_input_EN');
