% This script trains the route and tests navigation
close all
clear
clc
tic

load world5000_gray;
load img_pos;
trained_route = img_pos;

% Details of trained route 
route_length = size(trained_route,1);
feeder = trained_route(1,:)';% 2D location of the feeder on XY plane
nest = trained_route(20,:)';% 'route_length'; 2D location of the nest

% 1) TRAIN: Load the weights learned in training
load ./weight_matrix_KC_EN;

% 2) TEST if the ant goes back to nest
% The infinity accounts for losting occassions
% Parameter preparation
step_size = 0.05; % 0.1,0.05,0.02,0.01[m]
step_count = 2;
infinity = route_length; % Upper limit of steps in a navigation
correct_threshold = 1;
scan_range = 180; % +-90 [degrees] centered in current moving direction
scan_spd = 20; % 10, 20[degrees]
scan_img = scan_range/scan_spd + 1; % number of images that needed to be test
eye_height = 0.01; % [m]
resolution = 1; % [degrees/pixel]
fov = 360; % [degrees]
inputs = zeros(360,1);

% record spikes and rotation angle at each step
% 1: rotation angle relative to current moving direction in degrees
% 2: EN spikes
% 3: if scanning at the position
% 4: absolute heading direction relative to x axis in degrees
% 5: most familiar index
step_record = zeros(5,route_length);

% Recording positions at each step
current_position = zeros(2,route_length); 
current_position(:,1) = feeder; % Released at the feeder

% Recording the moving direction at each step
% In the first step the correct homing direction is given to the ant
% such that the ant moves one step further along the direction
moving_direction = zeros(2,route_length);
moving_direction(:,1) = (nest - feeder)/norm(nest - feeder);
current_position(:,2) = current_position(:,1) + step_size*moving_direction(:,1);
step_record(:,1) = [0, 0, 0, atan2(moving_direction(2,1),moving_direction(1,1))*180/pi,0];

% Start navigating
for step_count = 2:infinity
    raw_images = struct;
    step_count
    scanning = 0;
    % last position and moving direction
    moving_direction(:,step_count) = (current_position(:,step_count)...
        - current_position(:,step_count-1))...
        /norm(current_position(:,step_count)...
        - current_position(:,step_count-1));
    % current heading
    heading = atan2(moving_direction(2,step_count),moving_direction(1,step_count))*180/pi;
    % get current view along current moving direction
    raw_images(1).raw_image = ImgGrabber(current_position(1,step_count),current_position(2,step_count),eye_height,heading,X,Y,Z,colp,fov,resolution);
    %************** extract feature *****************
    inputs = extract_feature2(raw_images,step_count);
    %************** extract feature *****************

    % if the whole view is covered by grass,go along the original direction
    if sum(sum(inputs)) == 0
        display('run into grass, moving forward');
        step_record(:,step_count) = [0, 0, 0, heading];
        current_position(:,step_count+1) = current_position(:,step_count)...
            + moving_direction(:,step_count)*step_size;
        
    else
        norm_inputs = naive_visual_input(inputs);
        % test network with the image to get number of spikings
        display('testing')
        test;
        step_record(1:2,step_count)'
        if step_record(2,step_count) <= correct_threshold
            % one step further along current moving direction
            display('familiar, moving forward');
            current_position(:,step_count+1) = current_position(:,step_count)...
                + moving_direction(:,step_count)*step_size;
            step_record(4,step_count) = heading;
        else
            % scan 180 degrees and pre-process
            display('unfamiliar, scanning');
            step_record(3,step_count) = 1;
            scanning = 1;            
            headings(1) = atan2(moving_direction(2,step_count),moving_direction(1,step_count))*180/pi + scan_range/2;
            % getting all the images
            for i = 1:scan_img
                heading(i) = heading(1) - scan_spd*(i-1);
                raw_images(i).raw_image = ImgGrabber(current_position(1,step_count),current_position(2,step_count),eye_height,heading(i),X,Y,Z,colp,fov,resolution);
            end
            
            inputs = extract_feature2(raw_images,step_count);            
            norm_inputs = naive_visual_input(inputs);
            % get most familiar direction and move one step further
            test;
            step_record(1:2,step_count)'
            rotation_matrix = [cos(step_record(1,step_count)/180*pi),-sin(step_record(1,step_count)/180*pi);sin(step_record(1,step_count)/180*pi),cos(step_record(1,step_count)/180*pi)];
            step_transformation = moving_direction(:,step_count)'*step_size*rotation_matrix;    
            current_position(:,step_count+1) = current_position(:,step_count) + step_transformation';
            % update the correct moving direction for the current position
            moving_direction(:,step_count) = (current_position(:,step_count+1)...
                - current_position(:,step_count))...
                /norm(current_position(:,step_count+1)...
                - current_position(:,step_count));
            step_record(4,step_count) = atan2(moving_direction(2,step_count),moving_direction(1,step_count))*180/pi;
        end
    end
    
    % if reaches the nest, then break
    current_distance = norm(nest - current_position(:,step_count));
    if current_distance <= step_size
        break;
    end        
end

save('./results1/test_route','current_position');

close all

patch(X',Y',Z')
hold on
plot(current_position(1,1:infinity+1),current_position(2,1:infinity+1),'r','LineWidth',1.5);
plot(trained_route(:,1),trained_route(:,2),'b','LineWidth',1.5);
toc