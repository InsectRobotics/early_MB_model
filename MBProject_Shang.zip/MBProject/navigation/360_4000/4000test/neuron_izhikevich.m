function [v,u,spike] = neuron_izhikevich(v,u,dt,C,k,vr,vt,I,a,b,c,d,gaussian_mean,gaussian_std)
%izhikevich_neuron creates a single neuron model: takes in input current I,
%ouputs membrane potential v and current u and produces a spike or not.
%   v: membrane potential   u: recovery current
%  dt: time step            C: membrane capacitance
%   k: rheobase            vr: resting membrane potential
%  vt: instantaneous threshold protential
%   I: Input current        a: recovery time constant
%   b: input resistance (u is amplifying/resonant)
%   c: voltage reset value
%   d: outward minus inward currents
% gaussian_mean and std: noise N~(mean,std^2)

% spike: 1 for a spike, 0 for none
spike = zeros(size(v,1),1);

%spike = zeros(1,1);
% Noise term
noise = gaussian_mean + gaussian_std * randn(size(v,1),1);

% Derivatives
% dvdt(i) = (k * (v(i) - vr)*(v(i) - vt) - u(i) + I(i) + noise(i))/C;
% dudt(i) = a*(b*(v(i) - vr) - u(i));
dvdt = (k * (v - vr).*(v - vt) - u + I + noise)./C;
dudt = a*(b*(v - vr) - u);

% New v and u at time t+1
v = v + dvdt * dt;
u = u + dudt * dt;

% If a spike is fired, reset parameters
% ???compare with vt or a separate voltage peak
% if v > vt
%     v = c;
%     u = u + d;
%     spike = 1;
% end

spike = (v > vt);
v = c * spike + v.*(~spike);
u = u + d * spike;

end



