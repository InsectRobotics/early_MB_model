function [norm_inputs] = naive_visual_input(inputs)
% Generates pseudo visual inputs to PNs: 49*1 vector,
% each value represents the height of the sampled spot of the
% scene.
number_of_PN = 360;
variance = 800;
sensitivity = 290;
number_of_images = size(inputs,2);
% Normalise the input current:
norm_inputs = zeros(number_of_PN,number_of_images);
normalisation = sqrt(sum(inputs.*inputs));
deviation = std(inputs);

for i = 1:number_of_images
    if normalisation(i) == 0
        norm_inputs(:,i) = zeros(number_of_PN,1);
    else
        norm_inputs(:,i) = inputs(:,i)/normalisation(i)*variance + sensitivity;
    end
end

% for i = 1:number_of_images
%     if normalisation(i) == 0
%         norm_inputs(:,i) = zeros(number_of_PN,1);
%     elseif deviation(i)>=0.3
%         norm_inputs(:,i) = inputs(:,i)/normalisation(i)*variance + sensitivity;    
%     elseif deviation(i)>=0.25
%         norm_inputs(:,i) = inputs(:,i)/normalisation(i)*variance + sensitivity+10;
%     elseif deviation(i)>=0.23
%         norm_inputs(:,i) = inputs(:,i)/normalisation(i)*variance + sensitivity+11;
%     else
%         norm_inputs(:,i) = inputs(:,i)/normalisation(i)*variance + sensitivity+17;
%     end
% end

% input_strength = (sum(norm_inputs)./20000).^3;
% input_similarity = measure_similarity(norm_inputs);
% save('input_similarity','input_similarity');
% save('input_strength','input_strength');
% save('norm_inputs','norm_inputs');
% sum(norm_inputs)
