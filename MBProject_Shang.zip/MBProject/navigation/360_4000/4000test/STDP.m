function [tag_change] = STDP(delta_t)
%STDP returns the amount of change in the synaptic weight depending on the
% amount of time between pre- and postsynaptic spike.
% delta_t = t_pre - t_post

% Parameters
A_plus = 1;
A_minus = -1;
tau_plus = 25; % [ms]
tau_minus = 25; % [ms]

tag_change = -A_plus * exp(delta_t./tau_plus).*(delta_t<0);
for i = 1:size(delta_t,1)
%     if delta_t(i) < 0
%         tag_change(i) = A_plus * exp(delta_t(i)/tau_plus);
%     else
    if delta_t(i)>= 0
        tag_change(i) = A_minus * exp(-delta_t(i)/tau_minus);
    end
end

%tag_change = A_plus * exp(delta_t./tau_plus).*(delta_t<0) + A_minus * exp(-delta_t./tau_minus).*(~(delta_t<0));
end

