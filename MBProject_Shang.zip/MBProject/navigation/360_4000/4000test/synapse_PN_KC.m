function [S] = synapse_PN_KC(dt,spike,S)
% Visual input neuron to Kenyen cell synapse: general synapse

phi = 0.5;
tau_syn = 1; % [ms] synaptic timescale

[S] = synapse(dt,spike,S,phi,tau_syn);

end