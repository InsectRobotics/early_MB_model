function [v,u,spike] = neuron_KC(dt,v,u,I)
% Kenyon cell model: izhikevich neuron with specific parameters.

C = 4;
a = 0.01;
b = -0.3;
c = -65;
d = 8;
k = 0.015;
vr = -85;
vt = -25;
gaussian_mean = 0;
gaussian_std = 0.05;

[v,u,spike] = neuron_izhikevich(v,u,dt,C,k,vr,vt,I,a,b,c,d,gaussian_mean,gaussian_std);

end

