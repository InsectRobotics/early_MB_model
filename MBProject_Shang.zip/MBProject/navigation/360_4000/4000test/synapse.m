function [S] = synapse(dt,spike,S,phi,tau_syn)
%SYNAPSE Takes as input the current "state" of the synapse and
%outputs the estimated state (amount of transmitter) after time dt.

% spike indicates if a PRESYNAPTIC spike occurred. If so then spike should
% equal 1, otherwise 0.
% S is the amount of neurotransmitter active at the synapse at time t
% phi is a quantile of the amount of neurotransmitter released when a
% presynaptic spike occurred.

% Derivative of S
%dSdt = -S/tau_syn;
dSdt = -S./tau_syn;

% Update neurotransmitter with spike
S = S + dSdt .* dt + spike .* phi;

end

