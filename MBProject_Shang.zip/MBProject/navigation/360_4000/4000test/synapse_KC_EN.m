function [S,g,c,d] = synapse_KC_EN(dt,spike,S,g,c,delta_t,pre_post_spike_occured,d,BA )

%SYNAPSE_KC_EN Wrapper for the general synapse type to hold parameters for
%the KC-EN synapse

% spike indicates if a presynaptic spike occurred.
% tau_syn is the synaptic time constant.
% g is the synaptic weight or conductance
% c is the synaptic "tag"
% tau_c is a timeconstant associatec with the synaptic tag.
% delta_t = t_pre - t_post
% pre_post_spike_occured indicates if a pre- or postsynaptic spike occured.
% d is an extracellular concentration of a biogenic amine
% BA is the amount of BA released, the presentation of reinforcement in
% response to the correction of moving.

% Parameters
tau_c = 800; % [ms] time constant/ 800
tau_d = 50; % [ms]/ 80
g_max = 2; % maximal conductance/ 1
g_min = 0; % minimal conductance/ no minimal limit


phi = 8;
tau_syn = 5; % [ms]

% Update the transmitter
[S] = synapse(dt, spike, S, phi, tau_syn);

% Derivative of synaptic tag c, caused by STDP
dcdt = -c/tau_c + (STDP(delta_t).*pre_post_spike_occured)';

% Update tag c
c = c + dcdt * dt;

% Derivative of d, extracellular concentration of a biogenic amine
dddt = -d/tau_d;
% Update d
% d = dddt * dt + BA;
d = d + dddt * dt + BA;

% Derivative of g, synaptic conductance
%dgdt = c * d;
dgdt = c .* d;

% Update g
g = g + dgdt * dt;


% Why need a maximum value???
g(g > g_max) = g_max;
g(g < g_min) = g_min;

end