function [inputs] = extract_feature(raw_images,step_count)
% This function extracts 50 average heights
% The final inputs are normalised between 0 and 1

% Feature combination
input_num = 360;
inputs = zeros(input_num,size(raw_images,2));
edges = zeros(75,size(raw_images(1).raw_image,2),size(raw_images,2));

for j = 1 : size(raw_images,2)
    
    skyline = zeros(360,1);
    
    grayview = raw_images(j).raw_image(:,:,2);    
    edges(:,:,j) = edge(grayview,'canny',[0,0.1]);
    edge1 = edges(75:-1:1,:,j);
    idx = find(edge1 == 1);
    [r,c,p] = ind2sub(size(edge1), idx);
    [pixel_idx, skyline_idx, ic] = unique(c);
    skyline(pixel_idx) = r(skyline_idx);

    unnorm_inputs = skyline;
    % normalise to 0-1 by dividing maximum value
    inputs(:,j) = 1-unnorm_inputs/max(unnorm_inputs);

end
