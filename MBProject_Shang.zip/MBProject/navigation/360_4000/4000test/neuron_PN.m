function [v,u,spike] = neuron_PN(dt,v,u,I)
% Naive visual input neuron: take in visual input and connects directely to
% KC layer

C = 100;
a = 0.3;
b = -0.2;
c = -65;
d = 8;
k = 2;
vr = -60;
vt = -40;
gaussian_mean = 0;
gaussian_std = 0.05;

[v,u,spike] = neuron_izhikevich(v,u,dt,C,k,vr,vt,I,a,b,c,d,gaussian_mean,gaussian_std);

end

