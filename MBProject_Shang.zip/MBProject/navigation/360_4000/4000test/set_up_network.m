% This script sets up the three-layered network:
% First layer: 49 visual input neurons
% Second layer: 720 Kenyon cells
% Third layer: 1 extrinsic neuron

% Parameters:
number_of_PN = 360;
number_of_KC = 4000;
number_of_EN = 1;
initial_g_PN_KC = 0.24; % Initialise synaptic conductance
initial_g_KC_EN = 2;

% 1) Glomeruli (holding inputs)
% GL = zeros(number_of_PN,1); % Activity "GL_i" from the paper.

% 2) Set up neurons with initial membrane potential (first column) and
%    recovery current (second column).
%    Resting potential: v = -60mV
%    PN_u initialise to -1.7 to avoid high initial activity
PN = [-60*ones(number_of_PN,1), 0*ones(number_of_PN,1)]; % Visual input neurons
%    KC_u initialise to 9 to avoid high initial activity
KC = [-85*ones(number_of_KC,1), 0*ones(number_of_KC,1)]; % Kenyon cells
%    EN_u initialise to -0.05 to avoid high initial activity
EN = [-60*ones(number_of_EN,1), 0*ones(number_of_EN,1)]; % Extrinsic neurons

%  3) Set up connections
% number_connections_PN_KC = 10; % How many KCs a PN connects to.
% connection_matrix_PN_KC = zeros(number_of_PN,number_of_KC);
% number_connections_PN_KC = 10; % How many KCs a PN connects to.
% while true
%     connection_matrix_PN_KC = zeros(number_of_PN,number_of_KC);
%     for i_kc = 1 : number_of_KC
%         PN_selection = randperm(number_of_PN); % Select KCs to randomly to connect to.
%         connection_matrix_PN_KC(PN_selection(1:number_connections_PN_KC)',i_kc) = 1;
%     end
%     if max(sum(connection_matrix_PN_KC,2))- min(sum(connection_matrix_PN_KC,2)) <= 25 
%         break;
%     end
% end
% save('PN_KC_connection','connection_matrix_PN_KC');
load PN_KC_connection;

% 3b) KC - EN connections
connection_matrix_KC_EN = ones(number_of_KC,number_of_EN); % All KC connect to the EN.

% 4) Set up synapses
[m_PN_KC,n_PN_KC] = size(connection_matrix_PN_KC);
[m_KC_EN,n_KC_EN] = size(connection_matrix_KC_EN);

% 4a) g: Initialize synaptic weight/conductance

weight_matrix_PN_KC = connection_matrix_PN_KC * initial_g_PN_KC; % FILL IN SPECIAL VALUE HERE (3-6 simultaneous inputs)
if train_signal == 1
    weight_matrix_KC_EN = connection_matrix_KC_EN * initial_g_KC_EN; % FILL IN SPECIAL VALUE HERE ("low")
end
% 4b) S: Amount of neuro transmitter
synapses_PN_KC = zeros(m_PN_KC,n_PN_KC);
synapses_KC_EN = zeros(m_KC_EN,n_KC_EN);

% 4c) c: synaptic tag
synaptic_tag_KC_EN = zeros(m_KC_EN,n_KC_EN);

% 4d) d: concentration of biogetic amines
concentration_BA_KC_EN = zeros(m_KC_EN,n_KC_EN);

% 5) Set up spike vector
spike_PN = zeros(number_of_PN,1);
spike_KC = zeros(number_of_KC,1);
spike_EN = zeros(number_of_EN,1);

% 6) Set up input current vector
I_PN = zeros(number_of_PN,1);
I_KC = zeros(number_of_KC,1);
I_EN = zeros(number_of_EN,1);

% 7) Set up last spike time vector
t_last_spike_KC = ones(number_of_KC,1)*(-100000); % make sure that this does not influence the simulation.
t_last_spike_EN = ones(number_of_EN,1)*(-100000); % make sure that this does not influence the simulation.