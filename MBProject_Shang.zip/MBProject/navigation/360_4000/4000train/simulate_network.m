% Sets up a network and simulates it. The first phase is the training
% phase, then comes a phase without reinforcement.
tic;

% Import data of training images
load norm_inputs;
interval = 300; % [ms]
estimated_limit = 80;
rounds = estimated_limit/5;

for r = 1:1%rounds

set_up_network;

% Total training time
number_of_train = 20;%5*r;
number_of_test = 40;%number_of_train + 50;
number_of_inputs = number_of_train + number_of_test;
t_end = interval*(number_of_inputs); % [ms]

% Time step:
dt = 0.25; % [ms]
number_of_steps = t_end/dt;
interval_steps = interval/dt;

% Input matrix
inputs_matrix = [norm_inputs(:,1:20),norm_inputs(:,1:20),norm_inputs(:,80:-1:60)];
inputs = zeros(number_of_PN,number_of_steps+1);
for i_step = 1:number_of_inputs
    inputs(:,(i_step-1)*interval_steps+1:(i_step-1/6)*interval_steps) = repmat(inputs_matrix(:,i_step),[1 interval_steps*5/6]);
    inputs(:,(i_step-1/6)*interval_steps+1:i_step*interval_steps) = zeros(number_of_PN,interval_steps/6);
end


% Reward signal
BA = 0;

% Recordings:
% total input current per population at each time step
total_current_PN = zeros(t_end/dt,1);
total_current_KC = zeros(t_end/dt,1);
total_current_EN = zeros(t_end/dt,1);
% spikes per population
spikes_over_time_PN = zeros(number_of_PN,0.2*t_end); % Estimated max spike frequency: 200 hz
spikes_over_time_KC = zeros(number_of_KC,0.2*t_end); % Estimated max spike frequency: 200 hz
spikes_over_time_EN = zeros(number_of_EN,0.2*t_end); % Estimated max spike frequency: 200 hz
spike_counter_PN = zeros(number_of_PN,1);
spike_counter_KC = zeros(number_of_KC,1);
spike_counter_EN = zeros(number_of_EN,1);
spike_each_input_EN = zeros(number_of_EN,number_of_inputs);
spike_each_input_KC = zeros(number_of_KC,number_of_inputs);
spike_each_input_PN = zeros(number_of_PN,number_of_inputs);
% neurotransmitter per synapse population at each time step
total_neurotransmitter_PN_KC = zeros(t_end/dt,1);
total_neurotransmitter_KC_EN = zeros(t_end/dt,1);
% individual voltage per population at each time step
voltage_PN = zeros(number_of_PN,t_end/dt);
voltage_KC = zeros(number_of_KC,t_end/dt);
voltage_EN = zeros(number_of_EN,t_end/dt);
current_PN = zeros(number_of_PN,t_end/dt);
current_KC = zeros(number_of_KC,t_end/dt);
current_EN = zeros(number_of_EN,t_end/dt);

% Prepare graphs
% close all
% scrsz = get(0,'ScreenSize');
%figure1 = figure('OuterPosition',[1 3*scrsz(4)/4 scrsz(3)/2 scrsz(4)/4]); % Left, Top
% figure2 = figure('OuterPosition',[1 2*scrsz(4)/4 scrsz(3)/2 scrsz(4)/4]); % Left, Middle
% figure3 = figure('OuterPosition',[1 1*scrsz(4)/4 scrsz(3)/2 scrsz(4)/4]); % Left, Bottom
%figure4 = figure('OuterPosition',[scrsz(3)/2+1 3*scrsz(4)/4 scrsz(3)/2 scrsz(4)/4]); % Right, Top
%figure5 = figure('OuterPosition',[scrsz(3)/2+1 2*scrsz(4)/4 scrsz(3)/2 scrsz(4)/4]); % Right, Middle
% figure6 = figure('OuterPosition',[scrsz(3)/2+1 1*scrsz(4)/4 scrsz(3)/2 scrsz(4)/4]); % Right, Bottom

for idt = 1 : number_of_steps
    
    t = idt*dt;
    I_PN = inputs(:,idt);
    i_input = floor(t/interval);
    BA = 0;
    
    if idt-i_input*interval_steps == 0
        i_input
        synaptic_tag_KC_EN = zeros(m_KC_EN,n_KC_EN);
        KC = [-85*ones(number_of_KC,1), 0*ones(number_of_KC,1)];
        t_last_spike_KC = ones(number_of_KC,1)*(-100000);
        t_last_spike_EN = ones(number_of_EN,1)*(-100000);
    end    
    
    
    % 1) Set input pattern
    %    Training the network with first two images: A+
    if 0 <= t && t < interval*number_of_train
        if interval_steps*5/6 == idt-i_input*interval_steps
            BA = 0.5; % Reward signal
        end                   
    end
    
    if interval_steps-1 == idt-i_input*interval_steps            
        if i_input >= 1
            spike_each_input_EN(i_input+1) = spike_counter_EN(1) - sum(spike_each_input_EN(1:i_input));
            spike_each_input_KC(:,i_input+1) = spike_counter_KC - sum(spike_each_input_KC(:,1:i_input),2);
            spike_each_input_PN(:,i_input+1) = spike_counter_PN - sum(spike_each_input_PN(:,1:i_input),2);
        else
            spike_each_input_EN(i_input+1) = spike_counter_EN(1);
            spike_each_input_KC(:,i_input+1) = spike_counter_KC;
            spike_each_input_PN(:,i_input+1) = spike_counter_PN;
        end
    end  
    
    %  2) Calculate neuro transmitter (synapses)
    % 2a) PN_KC synapses    
    A = reshape(connection_matrix_PN_KC',1,number_of_PN*number_of_KC);
    B = reshape(synapses_PN_KC',1,number_of_PN*number_of_KC);
    C = reshape(repmat(spike_PN,1,number_of_KC)',1,number_of_PN*number_of_KC);
    current_value = A.*B;
    D = synapse_PN_KC(dt,C,current_value);
    synapses_PN_KC = reshape(D,number_of_KC,number_of_PN)';
     
    total_neurotransmitter_PN_KC(idt) = sum(sum(synapses_PN_KC)); % Record
    
    % 2b) KC_EN synapses
    r_connection_matrix_KC_EN = reshape(connection_matrix_KC_EN',1,number_of_KC*number_of_EN);
    r_synapses_KC_EN = reshape(synapses_KC_EN',1,number_of_KC*number_of_EN);
    current_value = r_connection_matrix_KC_EN .* r_synapses_KC_EN;
    g = weight_matrix_KC_EN'.* r_connection_matrix_KC_EN;
    c = synaptic_tag_KC_EN'.* r_connection_matrix_KC_EN;
    d = concentration_BA_KC_EN';
    pre_post_spike_occured = spike_KC|spike_EN;
    delta_t = (t_last_spike_KC - t_last_spike_EN) .* pre_post_spike_occured;
    [S, g, c, d] = synapse_KC_EN(dt, spike_KC', current_value, g, c, delta_t, pre_post_spike_occured, d, BA);
    synapses_KC_EN = reshape(S,number_of_EN,number_of_KC)';
    weight_matrix_KC_EN = g';
    synaptic_tag_KC_EN = c';
    concentration_BA_KC_EN = d';
    
    total_neurotransmitter_KC_EN(idt) = sum(sum(synapses_KC_EN)); % Record
    
    %  3) Calculate input currents:
    % 3a) Get input for PN from glomeruli with normalisation
    total_current_PN(idt) = sum(I_PN); % Record

    % 3b) Input to KC
    %     Reversal potential: 0mV for excitatory synapses, -92mV for
    %     inhibitory synapses    
    r_volt_KC = repmat((0 - KC(:,1))',number_of_PN,1);
    I_KC = sum(connection_matrix_PN_KC.* weight_matrix_PN_KC .* synapses_PN_KC .* r_volt_KC)'; 
    total_current_KC(idt) = sum(I_KC); % Record
    
    % 3c) Input to EN
    r_volt_EN = repmat((0 - EN(:,1))',number_of_KC,1);
    I_EN = sum(connection_matrix_KC_EN.* weight_matrix_KC_EN .* synapses_KC_EN .* r_volt_EN)';
    total_current_EN(idt) = sum(I_EN); % Record
    
    %  4) Update neurons (and record spikes)
    % 4a) PN neurons
    [PN(:,1), PN(:,2), spike_PN] = neuron_PN(dt, PN(:,1), PN(:,2), I_PN);
    spike_counter_PN = spike_counter_PN + spike_PN;
    [row_ind,cow] = find(spike_PN == 1);
    cow_ind = spike_counter_PN(spike_PN.*spike_counter_PN ~= 0);
    indices = sub2ind(size(spikes_over_time_PN),row_ind,cow_ind);
    spikes_over_time_PN(indices) = t;
    
    voltage_PN(:,idt) = PN(:,1); % Record
    current_PN(:,idt) = PN(:,2);
    
    % 4b) KC neurons
    [KC(:,1), KC(:,2), spike_KC] = neuron_KC(dt, KC(:,1), KC(:,2), I_KC);
    spike_counter_KC = spike_counter_KC + spike_KC;
    [row_ind,cow] = find(spike_KC == 1);
    cow_ind = spike_counter_KC(spike_KC.*spike_counter_KC ~= 0);
    indices = sub2ind(size(spikes_over_time_KC),row_ind,cow_ind);
    spikes_over_time_KC(indices) = t;
    t_last_spike_KC = t * spike_KC + t_last_spike_KC .* (~spike_KC);
     
    voltage_KC(:,idt) = KC(:,1); % Record
    current_KC(:,idt) = KC(:,2);
    
    % 4c) EN neurons
    [EN(:,1), EN(:,2), spike_EN] = neuron_EN(dt, EN(:,1), EN(:,2), I_EN);
    for i_EN = 1 : number_of_EN        
        if spike_EN(i_EN) == 1
            spike_counter_EN(i_EN) = spike_counter_EN(i_EN) + 1; % Advance spike counter
            spikes_over_time_EN(i_EN,spike_counter_EN(i_EN)) = t;
            t_last_spike_EN(i_EN) = t;
        end
    end    
    voltage_EN(:,idt) = EN(:,1); % Record
    current_EN(:,idt) = EN(:,2);
end

%r = 0;
spiking_KC_each_input = sum(spike_each_input_KC>0);
spiking_PN_each_input = sum(spike_each_input_PN>0);
save(sprintf('./results%d/spiking_KC',r),'spiking_KC_each_input');
save(sprintf('./results%d/spiking_PN',r),'spiking_PN_each_input');
save(sprintf('./results%d/spike_each_input_KC',r),'spike_each_input_KC');
save(sprintf('./results%d/spike_each_input_EN',r),'spike_each_input_EN');
save(sprintf('./results%d/weight_matrix_KC_EN',r),'weight_matrix_KC_EN');
% save(sprintf('./results%d/total_current_PN',r),'total_current_PN');
% save(sprintf('./results%d/total_current_KC',r),'total_current_KC');
% save(sprintf('./results%d/total_current_EN',r),'total_current_EN');
% save(sprintf('./results%d/spikes_over_time_PN',r),'spikes_over_time_PN');
% save(sprintf('./results%d/spikes_over_time_KC',r),'spikes_over_time_KC');
% save(sprintf('./results%d/spikes_over_time_EN',r),'spikes_over_time_EN');
% save(sprintf('./results%d/total_neurotransmitter_PN_KC',r),'total_neurotransmitter_PN_KC');
% save(sprintf('./results%d/total_neurotransmitter_KC_EN',r),'total_neurotransmitter_KC_EN');
% save(sprintf('./results%d/voltage_PN',r),'voltage_PN');
% save(sprintf('./results%d/voltage_KC',r),'voltage_KC');
% save(sprintf('./results%d/voltage_EN',r),'voltage_EN');
% save(sprintf('./results%d/current_PN',r),'current_PN');
% save(sprintf('./results%d/current_KC',r),'current_KC');
% save(sprintf('./results%d/current_EN',r),'current_EN');
%r = 1;
end

toc;