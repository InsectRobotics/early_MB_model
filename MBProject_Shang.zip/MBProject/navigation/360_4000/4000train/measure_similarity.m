function [similarity] = measure_similarity(images)
% This function measures similarity between images

[number_of_dimensions,number_of_images] = size(images);
similarity = zeros(number_of_images);
scaling = 1000;

for i = 1: number_of_images
    for j = 1: number_of_images
        difference = images(:,i)/scaling - images(:,j)/scaling;
        similarity(i,j) = -sum(difference.^2);
    end
end

end