% Generates pseudo visual inputs to PNs: 49*1 vector,
% each value represents the height of the sampled spot of the
% scene.
number_of_inputs = 81;
number_of_PN = 50;
variance = 800;%2530;%2000;%300;%400;%500*;%600*;%700;%800
sensitivity = 293;%0;%101;%371.2;%355.7;%340*;%324*;%308;%292.5
r=1;

load inputs;
% Normalise the input current:
norm_inputs = zeros(number_of_PN,number_of_inputs);
normalisation = sqrt(sum(inputs.*inputs));
deviation = std(inputs);


for i = 1:number_of_inputs
    if normalisation(i) == 0
        norm_inputs(:,i) = zeros(number_of_PN,1);
    else
        norm_inputs(:,i) = inputs(:,i)./normalisation(i)*variance+sensitivity;
    end
end

% for plotting together with similarity: 
%input_strength = (sum(norm_inputs)./20000).^3;
input_strength = sum(norm_inputs); 
input_similarity = measure_similarity(norm_inputs);
save(sprintf('./results%d/input_similarity',r),'input_similarity');
save(sprintf('./results%d/input_strength',r),'input_strength');
save(sprintf('./results%d/norm_inputs',r),'norm_inputs');
save('norm_inputs','norm_inputs');
sum(norm_inputs)
