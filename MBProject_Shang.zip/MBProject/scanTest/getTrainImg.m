% getTrainImg gets training images along a route
% With Mike's heading data

load AntData;
load world5000_gray;

% retrieve a route from AntData
route = Ant1.InwardRouteData.Route1.One_cm_control_points/100;
heading = Ant1.InwardRouteData.Route1.One_cm_control_points_headings;

% get an image very 10 cm
img_separation = 10; % [cm]
img_limit = floor(size(route,1)/10)*10;
% 80 image positions
img_pos = zeros(2,2);
img_pos = route(1:img_separation:img_limit,:);

% parameters for invoking getViewPan
eye_height = 0.01; % [m]
resolution = 1; % [degrees/pixel]
fov = 360; % [degrees]
heading = heading(1:img_separation:img_limit,:); % [degrees]
% save raw images in structure F
Raw_images = struct;

% ******************************************************
% Used to test if there is a valley at 0 rotation
scan_range = 180;
scan_spd = 2;
img_num = scan_range/scan_spd + 1;
% ******************************************************

% choose a specific position and test a 180 scan
pos_index = 1;
for i = 1:img_num
    current_heading = heading(pos_index) + scan_range/2 - scan_spd*(i-1);
    Raw_images(i).raw_image = ImgGrabber(img_pos(pos_index,1),img_pos(pos_index,2),eye_height,current_heading,X,Y,Z,colp,fov,resolution);
    pause(0.5);
end

save('Raw_images','Raw_images');

